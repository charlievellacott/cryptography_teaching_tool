﻿using CryptographyTeachingTool.Help;
using CryptographyTeachingTool.MainClasses;
using CryptographyTeachingTool.UI;
using CryptographyTeachingTool.UI.Basic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CryptographyTeachingTool.UI.Demonstrations
{
    public partial class DemosBasePage : Form
    {
        protected User currentUser;
        protected Button helpbtn;
        protected Button backbtn;

        public DemosBasePage(User user)
        {
            this.currentUser = user;
            ClientSize = new Size(1142, 750);
            helpbtn = InitalizeHelpButton();
            backbtn = InitalizeBacktoDashBtn();
            helpbtn.BringToFront();
            backbtn.BringToFront();
            this.FormClosed += ClosingApplication;
        }

        private Button InitalizeHelpButton()
        {
            Button btn = new Button();
            btn.Text = "Help";
            btn.Size = new Size(150, 40);
            btn.Location = new Point(10, this.ClientSize.Height - btn.Height - 10); // bottom-left corner
            btn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btn.Click += HelpButtonClick;
            btn.BackColor = Color.FromArgb(47, 54, 64);
            btn.ForeColor = Color.FromArgb(220, 221, 225);
            Controls.Add(btn);
            return btn;
        }
        private void HelpButtonClick(object? sender, EventArgs e)
        {
            HelpForm helpForm = new HelpForm();
            helpForm.Show();
        }

        private Button InitalizeBacktoDashBtn()
        {
            Button btn = new Button();
            btn.Text = "Back";
            btn.Size = new Size(150, 40);
            btn.BackColor = Color.FromArgb(47, 54, 64);
            btn.ForeColor = Color.FromArgb(220, 221, 225);
            btn.Location = new Point(
                this.ClientSize.Width - btn.Width - 10,
                this.ClientSize.Height - btn.Height - 10); // bottom right corner
            Controls.Add(btn);
            btn.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btn.Click += BackToDashboardButton;
            return btn;
        }
        private void BackToDashboardButton(object? sender, EventArgs e)
        {
            GeneralDashboardForm dash = new GeneralDashboardForm(currentUser);
            dash.Show();
            this.Hide();
        }

        protected void ClosingApplication(object sender, FormClosedEventArgs e)
        {
            GeneralDashboardForm dash = new GeneralDashboardForm(currentUser);
            dash.Show();
            this.Hide();
        }

    }
}
