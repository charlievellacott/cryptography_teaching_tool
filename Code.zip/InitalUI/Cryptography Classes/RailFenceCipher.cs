﻿using CryptographyTeachingTool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CryptographyTeachingTool.Cryptography.Ciphers
{
    public class RailFenceCipher : CryptographicAlgorithm
    {
        /// <summary>
        /// The CryptographicAlgorithm will be a parent to this class. 
        /// Railfence is a transposition cipher that will need its own methods 
        /// therefore extra will be added into this class.
        /// </summary>

        public override string Encrypt(int key, string plainText)
        {
            // This static method overrides the original Encrypt method in CryptographicAlgorithm.
            // It is used to perform a railfence cipher on a string using a given key.
            // The result is returned as a single string.

            char[,] matrix = new char[key, plainText.Length];

            int row = 0;
            bool isDecreasing = true;
            for (int column = 0; column < plainText.Length; column++)
            {
                matrix[row, column] = plainText[column];

                if (row == key - 1)
                {
                    isDecreasing = false;
                }
                else if (row == 0)
                {
                    isDecreasing = true;
                }

                if (isDecreasing)
                {
                    row++;
                }
                else
                {
                    row--;
                }
            }

            string cipherText = "";
            for (row = 0; row < key; row++)
            {
                for (int column = 0; column < plainText.Length; column++)
                {
                    if (matrix[row, column] != '\0')
                    {
                        cipherText += matrix[row, column];
                    }
                }
            }
            return cipherText;
        }

        public override string Decrypt(int key, string cipherText)
        {
            // This static method overrides the original Decrypt method in CryptographicAlgorithm.
            // It then decrypts a cipher text given the key and cipher text as a string.
            // The encryption process is different to the Encrypt process which is why a negative key 
            // cannot be used. The result is returned as a single string.
            
            char[,] matrix = new char[key, cipherText.Length];

            int row = 0;
            bool isDecreasing = true;
            for (int column = 0; column < cipherText.Length; column++)
            {
                matrix[row, column] = '*';

                if (row == key - 1)
                {
                    isDecreasing = false;
                }
                else if (row == 0)
                {
                    isDecreasing = true;
                }

                if (isDecreasing)
                {
                    row++;
                }
                else
                {
                    row--;
                }
            }

            int count = 0;
            for (row = 0; row < key; row++)
            {
                for (int column = 0; column < cipherText.Length; column++)
                {
                    if (matrix[row, column] == '*')
                    {
                        matrix[row, column] = cipherText[count];
                        count++;
                    }
                }
            }

            row = 0;
            isDecreasing = true;
            string plainText = "";
            for (int column = 0; column < cipherText.Length; column++)
            {
                plainText += matrix[row, column];

                if (row == key - 1)
                {
                    isDecreasing = false;
                }
                else if (row == 0)
                {
                    isDecreasing = true;
                }

                if (isDecreasing)
                {
                    row++;
                }
                else
                {
                    row--;
                }
            }

            return plainText;
        }
    }

}
