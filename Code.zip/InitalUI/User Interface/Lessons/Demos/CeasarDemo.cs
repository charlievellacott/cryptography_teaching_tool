﻿using CryptographyTeachingTool.Cryptography;
using CryptographyTeachingTool.Cryptography.Ciphers;
using CryptographyTeachingTool.Help;
using CryptographyTeachingTool.MainClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CryptographyTeachingTool.UI.Demonstrations
{
    public partial class CeasarDemo : DemosBasePage
    {
        public CeasarDemo(User user) : base(user)
        {
            InitializeComponent();
        }
        private void EncryptButtonClick(object sender, EventArgs e)
        {
            string plainText = PlainTextBox.Text;
            int key = Convert.ToInt32(KeySelector.Value);
            CaesarCipher caesar = new CaesarCipher();
            string result = caesar.Encrypt(key, plainText);
            CipherTextBox.Text = result;
        }

        private void DecryptButtonClick(object sender, EventArgs e)
        {
            string plainText = CipherTextBox.Text;
            int key = Convert.ToInt32(KeySelector.Value);
            CaesarCipher caesar = new CaesarCipher();
            string result = caesar.Decrypt(key, plainText);
            PlainTextBox.Text = result;
        }
    }
}
