﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Microsoft.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using CryptographyTeachingTool;
using CryptographyTeachingTool.Cryptography;
using CryptographyTeachingTool.Data.Repositories;
using CryptographyTeachingTool.Cryptography.Hash;

namespace CryptographyTeachingTool.Login
{
    public partial class SignUpForm : Form
    {
        private LoginForm loginSender;
        public SignUpForm(LoginForm loginForm)
        {
            loginSender = loginForm;
            InitializeComponent();
            this.FormClosed += OnFormClosed;
        }

        private void OnFormClosed(object? sender, FormClosedEventArgs e)
        {
            loginSender.Show();
        }

        private void SignUpButtonClick(object sender, EventArgs e)
        {
            // This method takes all the user's input, validates it
            // (including calling the UserExists method as part of the
            // UserRepo class to check the username is unique) and then if suitable
            // an entry to the Users database is created with the added details.
            // Note the password is also validated as part of this window.

            string fname = Firstname.Text;
            string sname = Surname.Text;
            string uname = Username.Text;
            SHA256Hash SHA = new SHA256Hash();
            string hashedPass = SHA.Hash(Password.Text);
            string role = RoleSelect.Text;

            // validation
            bool isValid = true;

            int upperCount = 0;
            int lowerCount = 0;
            int numbCount = 0;
            int specialCount = 0;
            foreach (char c in Password.Text)
            {
                if (Convert.ToInt16(c) >= 48 && Convert.ToInt16(c) <= 57)
                {
                    numbCount++;
                }
                else if (Convert.ToInt16(c) >= 65 && Convert.ToInt16(c) <= 90)
                {
                    upperCount++;
                }
                else if (Convert.ToInt16(c) >= 97 && Convert.ToInt16(c) <= 122)
                {
                    lowerCount++;
                }
                else
                {
                    specialCount++;
                }
            }

            if (fname == "" || sname == "" || uname == "" || Password.Text == "")
            {
                MessageBox.Show("Please fill in all details before submitting, none should be blank.");
                isValid = false;
            }
            else if (Password.Text.Length < 8) { MessageBox.Show("Your password must be at least 8 characters in length"); isValid = false; }
            else if (upperCount == 0) { MessageBox.Show("Your password must have an uppercase letter in"); isValid = false; }
            else if (lowerCount == 0) { MessageBox.Show("Your password must have a lowercase letter in"); isValid = false; }
            else if (numbCount == 0) { MessageBox.Show("Your password must have a number in"); isValid = false; }
            else if (specialCount == 0) { MessageBox.Show("Your password must have a special character in"); isValid = false; }

            // storing the data
            if (isValid)
            {
                if (!UserRepo.UserExists(uname))
                {
                    if (UserRepo.CreateUser(uname, hashedPass, fname, sname, role))
                    {
                        loginSender.Show();
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("The username you have entered is already in use");
                }
            }
        }
    }
}

