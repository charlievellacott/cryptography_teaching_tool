﻿using CryptographyTeachingTool.Data.Repositories;
using CryptographyTeachingTool.UI.Basic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CryptographyTeachingTool.UI.Student
{
    public partial class InputMarksForm : Form
    {
        private int ID;
        public InputMarksForm(ViewAssignments assign, int id)
        {
            this.ID = id;
            InitializeComponent();
        }

        private void UpdateMarksButtonClick(object sender, EventArgs e)
        {
            int MarksEntered = Convert.ToInt16(MarksInput.Value);
            if (MarksEntered < 0 )
            {
                MessageBox.Show("Please enter a mark that is greater than or equal to 0");
            }
            else
            {
                AssignmentRepo.UpdateMarks(MarksEntered, ID);
            }
            this.Hide();
        }
    }
}
